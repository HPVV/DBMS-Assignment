#2
SELECT User_Id, User_type, FName, LName, Age, DOB, pincode, street_no,year(curdate())-year(DOB) as Age FROM users;

#3
SELECT * FROM route_info WHERE Distance BETWEEN 70 and 150;

#4
SELECT * FROM route_info WHERE From_station_Name='Chennai' AND TO_station_Name='Sholingur';

#5
SELECT * FROM train WHERE NOT Train_type='Mail';

#6
SELECT * FROM train WHERE Source='Bengaluru' AND Destination='Chennai';

#7
SELECT * FROM ticket WHERE TIME("08:00:00") AND Departure='Chennai';

#8
SELECT * FROM users WHERE DOB BETWEEN '1980-01-01' AND '1990-01-01';

#9
SELECT User_ID, User_Type, FName, LName, Age, DOB, PinCode, Street_no FROM users WHERE FName LIKE('S%');

#10
SELECT * FROM compartment WHERE Train_no=62621 AND Type='I Class';

#11
SELECT * FROM payment_info WHERE Bank='Union Bank';
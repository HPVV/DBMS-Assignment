CREATE TABLE Train (
    Train_no INT NOT NULL,
    Train_name VARCHAR(25) NOT NULL,
    Train_type VARCHAR(25) NOT NULL,
    Destination VARCHAR(25),
    Availability VARCHAR(25),
    Source CHAR(35),
    PRIMARY KEY (Train_no)
);

CREATE TABLE Compartment (
    Compartment_no VARCHAR(10) NOT NULL,
    Type VARCHAR(25),
    Capacity INT,
    Availability VARCHAR(20) DEFAULT 'Yes',
    Train_no INT,
    PRIMARY KEY (Compartment_no,train_no),
    FOREIGN KEY (Train_no)
        REFERENCES Train (Train_no)
); 

CREATE TABLE Route_Info (
    From_Station_no INT NOT NULL,
    TO_Station_no INT NOT NULL,
    From_station_Name VARCHAR(255),
    TO_station_Name VARCHAR(255),
    Distance INT,
    Train_no INT,
    PRIMARY KEY (From_Station_no , TO_Station_no, Train_no),
    FOREIGN KEY (Train_no)
        REFERENCES Train (Train_no)
); 
                   
CREATE TABLE Users (
    User_Id VARCHAR(10) NOT NULL,
    User_type CHAR(25),
	Fname VARCHAR(25),
    Lname VARCHAR(25),
	Age VARCHAR(10),
    DOB DATE,
    pincode VARCHAR(25),
    Street_no VARCHAR(50),
    PRIMARY KEY (User_Id)
);
                   
CREATE TABLE User_Train (
    User_Id VARCHAR(10),
    Train_no INT,
    Date_time_Stamp DATETIME NOT NULL,
	PRIMARY KEY (Train_no, User_Id, Date_time_Stamp),
    FOREIGN KEY (Train_no)
        REFERENCES Train (Train_no),
    FOREIGN KEY (User_Id)
        REFERENCES Users (User_Id)
);    

CREATE TABLE User_Phone (
    User_Id VARCHAR(10),
	Phone_no BIGINT NOT NULL,
    FOREIGN KEY (User_Id)
        REFERENCES Users (User_Id),
    PRIMARY KEY (User_Id, Phone_no)
);
                        
CREATE TABLE Ticket (
    PNR VARCHAR(20) NOT NULL,
    Train_Number INT,
    Travel_date DATE,
    Departure CHAR(35),
	Arrival CHAR(35),
    Departure_time TIME,
    Arrival_time TIME,
    User_Id VARCHAR(20),
    PRIMARY KEY (PNR),
    FOREIGN KEY (User_Id)
        REFERENCES Users (User_Id)
);
 
CREATE TABLE Ticket_Passenger (
    Seat_no VARCHAR(10) NOT NULL,
    Name CHAR(50),
    Age INT,
    PNR VARCHAR(20),
    PRIMARY KEY (Seat_no,PNR),
    FOREIGN KEY (PNR)
        REFERENCES Ticket (PNR)
); 
                              
CREATE TABLE Payment_info (
    Transaction_Id INT NOT NULL,
    Bank CHAR(35),
    Card_no BIGINT,
    Price VARCHAR(10),
    PNR VARCHAR(10),
    FOREIGN KEY (PNR)
        REFERENCES Ticket (PNR),
    PRIMARY KEY (Transaction_Id, PNR)
);
                        
CREATE TABLE Fare_Table (
    Train_type VARCHAR(25) NOT NULL,
    Compartment_Type VARCHAR(25) NOT NULL,
    Fare_PerKM INT,
    PRIMARY KEY (Train_type , Compartment_Type)
); 


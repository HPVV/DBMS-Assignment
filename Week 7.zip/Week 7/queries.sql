INSERT INTO TICKET (PNR, Train_Number, Travel_date, User_ID,
Arrival_time, Departure_time, Train_Type, Compartment_Type, Compartment_no, Arrival, Departure)
VALUES ('PNR021', 62621, '2021-10-22', 'USR_008', '20:30:00',
'16:00:00', 'Superfast', 'I Class', 'F01','Chennai', 'Bengaluru' );

UPDATE TRAIN 
SET source = TRIM(Source),
	destination = TRIM(Destination);
    
#1
SELECT users.User_ID, User_Type, Fname, Lname FROM USERS, TICKET
WHERE TICKET.Departure = 'Bengaluru' AND TICKET.Arrival = 'Chennai'
UNION
SELECT users.User_ID, User_Type, Fname, Lname FROM USERS, TICKET
WHERE TICKET.Travel_Date BETWEEN '2022-08-01' AND '2021-10-01';




#2
SELECT users.User_ID, User_Type, Fname, Lname FROM USERS, TICKET
WHERE TICKET.Departure = 'Bengaluru' AND TICKET.Arrival = 'Chennai'
AND EXISTS
(SELECT users.User_ID, User_Type, Fname, Lname FROM USERS, TICKET
WHERE TICKET.Travel_Date BETWEEN '2022-08-01' AND '2021-10-01');

#3
SELECT usr.User_ID,
	   usr.User_Type,
	   usr.Fname,
	   usr.Lname
FROM USERS AS usr, TICKET AS t
WHERE
	usr.User_ID = t.User_ID AND t.Departure ='Bengaluru' AND t.Arrival ='Chennai' AND t.Travel_Date LIKE '2022-08-__' AND NOT EXISTS(
	SELECT
		usr.User_ID,
		usr.User_Type,
		usr.Fname,
		usr.Lname
	FROM Users AS usr, TICKET AS t
	WHERE usr.User_ID = t.User_ID AND t.Departure ='Bengaluru' AND t.Arrival ='Chennai' AND t.Travel_Date LIKE '2021-10-__');

#4
SELECT U1.User_ID, User_Type, Fname, Lname
FROM TICKET as T1, USERS as U1
WHERE T1.User_ID = U1.User_ID
AND T1.Departure = 'Bengaluru' AND T1.Arrival = 'Chennai'
AND EXISTS (SELECT PNR FROM TICKET AS T2 WHERE T1.User_ID = T2.User_ID 
AND T2.Departure = 'Chennai' AND T2.Arrival = 'Bengaluru' AND (DATEDIFF(T2.Travel_Date,T1.Travel_Date) BETWEEN 0 AND 7));



#5
SELECT U1.User_ID, User_Type, Fname, Lname
FROM TICKET as T1, USERS as U1
WHERE T1.User_ID = U1.User_ID
AND T1.Departure = 'Bengaluru' AND T1.Arrival = 'Chennai'
AND NOT EXISTS(SELECT PNR FROM TICKET AS TIC WHERE T1.User_ID = TIC.User_ID 
AND TIC.Departure = 'Chennai' AND TIC.Arrival = 'Bengaluru');

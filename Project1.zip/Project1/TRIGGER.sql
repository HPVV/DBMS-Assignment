create table dump
(
product_id varchar(30),
cost float,
seller_id varchar(20)
);


DELIMITER $$
create  trigger trig
after delete on product
for each row
begin
insert into dump values (OLD.product_id,OLD.cost,OLD.seller_id);
END  $$
DELIMITER ;

SET FOREIGN_KEY_CHECKS=0;

delete from product where Product_id='pid1001';

select * from dump ;
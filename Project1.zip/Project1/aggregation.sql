SELECT 
    SUM(quantity_wished * cost) total_payable
FROM product p
        JOIN
    cart_item c ON p.product_id = c.product_id
WHERE
    c.product_id IN (SELECT product_id FROM cart_item
        WHERE
            cart_id IN (SELECT Cart_id FROM customer
                WHERE
                    customer_id = 'cid101')
                AND purchased = 'Y');
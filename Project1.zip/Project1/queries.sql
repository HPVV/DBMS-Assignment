SELECT * FROM product
WHERE
    product_id IN (SELECT 
            product_id
        FROM
            Cart_item
        WHERE
            (Cart_id IN (SELECT 
                    Cart_id
                FROM
                    Customer
                WHERE
                    Customer_id = 'cid100'))
                AND purchased = 'Y');
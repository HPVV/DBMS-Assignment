    SELECT 
    SUM(quantity_wished * cost * commission / 100) total_profit
FROM
    product p
        JOIN
    cart_item c ON p.product_id = c.product_id
WHERE
    purchased = 'Y';
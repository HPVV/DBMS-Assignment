CREATE TABLE Cart (
    Cart_id VARCHAR(7) NOT NULL,
    PRIMARY KEY (Cart_id)
);

CREATE TABLE Customer (
    Customer_id VARCHAR(6) NOT NULL,
    c_pass VARCHAR(10) NOT NULL,
    Name VARCHAR(20) NOT NULL,
    Address VARCHAR(20) NOT NULL,
    Pincode INT NOT NULL,
    Phone_number_s BIGINT NOT NULL,
    PRIMARY KEY (Customer_id),
    Cart_id VARCHAR(7) NOT NULL,
    FOREIGN KEY (Cart_id)
        REFERENCES cart (Cart_id)
);

CREATE TABLE Seller (
    Seller_id VARCHAR(6) NOT NULL,
    s_pass VARCHAR(10) NOT NULL,
    Name VARCHAR(20) NOT NULL,
    Address VARCHAR(10) NOT NULL,
    PRIMARY KEY (Seller_id)
);

CREATE TABLE Seller_Phone_num (
    Phone_num BIGINT NOT NULL,
    Seller_id VARCHAR(6) NOT NULL,
    PRIMARY KEY (Phone_num , Seller_id),
    FOREIGN KEY (Seller_id)
        REFERENCES Seller (Seller_id)
);

    CREATE TABLE Payment (
    payment_id VARCHAR(7) NOT NULL,
    payment_date DATE NOT NULL,
    Payment_type VARCHAR(10) NOT NULL,
    Customer_id VARCHAR(6) NOT NULL,
    Cart_id VARCHAR(7) NOT NULL,
    PRIMARY KEY (payment_id),
    FOREIGN KEY (Customer_id)
        REFERENCES Customer (Customer_id),
    FOREIGN KEY (Cart_id)
        REFERENCES Cart (Cart_id),
    total_amount NUMERIC(6)
);

    CREATE TABLE Product (
    Product_id VARCHAR(7) NOT NULL,
    Type VARCHAR(7) NOT NULL,
    Color VARCHAR(15) NOT NULL,
    P_Size VARCHAR(2) NOT NULL,
    Gender CHAR(1) NOT NULL,
    Commission INT NOT NULL,
    Cost FLOAT NOT NULL,
    Quantity INT NOT NULL,
    Seller_id VARCHAR(6),
    PRIMARY KEY (Product_id),
    FOREIGN KEY (Seller_id)
        REFERENCES Seller (Seller_id)
);

    CREATE TABLE Cart_item (
    Quantity_wished INT NOT NULL,
    Date_Added DATE NOT NULL,
    Cart_id VARCHAR(7) NOT NULL,
    Product_id VARCHAR(7) NOT NULL,
    FOREIGN KEY (Cart_id)
        REFERENCES Cart (Cart_id),
    FOREIGN KEY (Product_id)
        REFERENCES Product (Product_id),
    PRIMARY KEY (Cart_id , Product_id)
);

alter table Cart_item add purchased varchar(3) default 'NO';
    
alter table seller modify address char(20);

alter table payment modify payment_type char(20);

alter table product modify type char(20);
insert into Customer (customer_id,c_pass,name,address,pincode,phone_number_s,cart_id) values
('cid100','ABCM1235','rajat','G-453','632014',9893135876, 'crt1011'),
('cid101','ABCM1254','vishal','G-310','560072',9739311122, 'crt1012'),
('cid102','ABCM1267','shashank','G-300','560098',8861563550, 'crt1013'),
('cid103','ABCM1289','kushal','G-100','560073',9880019534, 'crt1014'),
('cid104','ABCM1221','venki','G-12','560076',8073859507, 'crt1015'),
('cid105','ABCM1290','viggie','G-23','560021',8073756509, 'crt1016'),
('cid106','ABCM1300','niranjan','G-43','560034',8971908583, 'crt1017'),
('cid107','ABCM1201','rohan','G-210','560032',8101290765, 'crt1018'),
('cid108','ABCM1231','suma','G-98','560079',6361234651, 'crt1019'),
('cid109','ABCM1200','tejas','G-78','560090',9908112502, 'crt1020');

select * from customer;
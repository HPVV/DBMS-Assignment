insert into Seller_Phone_num (phone_num,seller_id) values
('9943336206','sid100'),
('9943337101','sid101'),
('9943338011','sid102'),
('9943339100','sid103'),
('9943567890','sid104'),
('9940987654','sid105'),
('9912345890','sid106'),
('9098765432','sid107'),
('9789031234','sid108'),
('9943450981','sid109');

select * from seller_phone_num;
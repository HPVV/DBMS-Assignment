insert into Cart_item (quantity_wished,date_added,cart_id,product_id,purchased) values
(3,'2022-01-30','crt1011','pid1001','Y'),
(4,'2022-02-01','crt1012','pid1002','Y'),
(1,'2022-03-14','crt1013','pid1003','Y'),
(2,'2022-04-25','crt1014','pid1004','Y'),
(6,'2022-05-11','crt1015','pid1005','Y'),
(7,'2022-06-29','crt1016','pid1006','Y'),
(11,'2022-07-18','crt1017','pid1007','Y'),
(10,'2022-08-20','crt1018','pid1008','Y'),
(8,'2022-09-21','crt1019','pid1009','Y'),
(9,'2022-10-25','crt1020','pid1010','Y');

select * from cart_item;
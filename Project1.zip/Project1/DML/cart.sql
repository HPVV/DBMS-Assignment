insert into Cart (cart_id) values
('crt1011'),
('crt1012'),
('crt1013'),
('crt1014'),
('crt1015'),
('crt1016'),
('crt1017'),
('crt1018'),
('crt1019'),
('crt1020');

select * from cart;
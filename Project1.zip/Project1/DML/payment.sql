insert into Payment (payment_id,payment_date,payment_type,customer_id,cart_id,total_amount) values
('pmt1001','2022-01-30','online','cid100','crt1011',NULL),
('pmt1002','2022-02-01','UPI','cid101','crt1012',NULL),
('pmt1003','2022-03-14','credit card','cid102','crt1013',NULL),
('pmt1004','2022-04-25','debit card','cid103','crt1014',NULL),
('pmt1005','2022-05-11','VISA','cid104','crt1015',NULL),
('pmt1006','2022-06-29','UPI','cid105','crt1016',NULL),
('pmt1007','2022-07-18','Cash','cid106','crt1017',NULL),
('pmt1008','2022-08-20','online','cid107','crt1018',NULL),
('pmt1009','2022-09-21','UPI','cid108','crt1019',NULL),
('pmt1010','2022-10-25','online','cid109','crt1020',NULL);

select * from payment;
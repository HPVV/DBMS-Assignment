insert into Product (product_id,type,color,p_size,gender,commission,cost,quantity,seller_id) values
('pid1001','jeans','red','32','M',10,10005.29,20,'sid100'),
('pid1002','shirt','green','42','F',15,980.14,15,'sid101'),
('pid1003','formal pant','violet','44','M',20,1010.32,10,'sid102'),
('pid1004','TShirt','black','30','M',25,999.10,5,'sid103'),
('pid1005','legins','white','28','F',20,780.34,9,'sid104'),
('pid1006','kurti','maroon','32','F',30,5600.90,30,'sid105'),
('pid1007','pajama','black and white','46','M',20,1234.12,12,'sid106'),
('pid1008','trousers','blue','30','M',30,9870.90,17,'sid107'),
('pid1009','Sweatshirt','purple','28','M',20,3450.32,15,'sid108'),
('pid1010','hoodies','yellow','40','F',34,1099.10,19,'sid109');

select * from product;
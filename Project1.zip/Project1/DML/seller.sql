insert into Seller (seller_id,s_pass,name,address) values
('sid100','12345','aman','delhi'),
('sid101','12345','suresh','bangalore '),
('sid102','12345','preethi','uttar pradesh'),
('sid103','12345','latha','jharkhand'),
('sid104','12345','venkatesh','tamilnadu'),
('sid105','12345','priya','telangana'),
('sid106','12345','naveen','orissa'),
('sid107','12345','bhuvaneshwar','gujarat'),
('sid108','12345','nithin','kerala'),
('sid109','12345','nagegowda','andhra');

select * from seller;
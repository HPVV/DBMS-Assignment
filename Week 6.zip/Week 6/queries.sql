

#1
select avg(Distance) AS "Average_distance",Train_No
FROM route_info 
where To_station_No - From_station_No =1
group by(Train_No);




#2
select avg(Distance) AS "Average_distance",Train_No
FROM route_info 
where To_station_No - From_station_No =1
group by(Train_No)
order by(avg(Distance)) desc;


#3
select sum(Distance) as "Total distance",Train_No
FROM route_info 
group by(Train_No)
order by(sum(Distance)) desc;




#4
SELECT Compartment_no, num
FROM(SELECT Compartment_no, COUNT(*) AS num FROM train
    INNER JOIN compartment ON train.Train_No = compartment.Train_No
    GROUP BY train.Train_no) AS t
WHERE num = (SELECT MAX(num) FROM (SELECT Compartment_no, COUNT(*) AS num FROM train
            INNER JOIN compartment ON train.Train_No = compartment.Train_No
            GROUP BY train.Train_no) AS t)
        OR num = (SELECT MIN(num)
        FROM(SELECT Compartment_no, COUNT(*) AS num
            FROM train
            INNER JOIN compartment ON train.Train_No = compartment.Train_No
            GROUP BY train.Train_no) AS t);





#5
select count(*),User_ID
from user_phone
where User_ID="ADM_001" or User_ID="USR_006" or User_ID="USR_010"
group by User_ID;






#6
select avg(Fare_PerKM),train_type
from fare_table
group by Train_Type;


#7
select *
from ticket_passenger
where age=(select max(age) from ticket_passenger);








#8
select count(*)
from ticket_passenger
where Name like "%Ullal";






CREATE VIEW compute_price AS
SELECT Ticket.PNR, Ticket.Train_Number, Ticket.Departure, Ticket.Arrival,
Route_Info.Distance, Fare_table.Fare_PerKM
FROM Ticket, Route_Info, Fare_table
WHERE (Ticket.Train_Number = Route_Info.Train_No AND
Ticket.Departure = Route_Info.From_Station_Name AND
Ticket.Arrival = Route_Info.To_Station_Name AND
Fare_table.Train_Type=Ticket.Train_Type AND
Fare_table.Compartment_Type =Ticket.Compartment_type);

SELECT * FROM railwayreservationsystem.compute_price;

CREATE VIEW passenger_num AS select PNR, count(PNR) as numbers from
Ticket_Passenger group by PNR;

SELECT * FROM railwayreservationsystem.passenger_num;

UPDATE Payment_Info AS p INNER JOIN compute_price AS cs 
ON p.PNR = cs.PNR INNER JOIN passenger_num AS pn 
ON cs.PNR = pn.PNR SET p.Price = cs.Distance * cs.Fare_PerKM * pn.numbers;

SELECT * FROM railwayreservationsystem.payment_info;

SELECT c.distance,
       c.From_station_name,
       c.To_station_name,
       c.From_station_No,
       c.To_station_No,
       c.Train_No,
       i.Train_No
FROM route_info AS c natural JOIN train AS i where c.To_station_No - c.From_station_No =1;




update route_info set from_station_no=3
where from_station_no=4 and to_station_no=4 and train_no=25260;

#3
SELECT 
	c.Availability,
    c.Train_No,
    i.Source,
    i.Destination    
FROM compartment AS c  inner JOIN train AS i 
where c.train_no =i.Train_No and c.Availability>10 and i.source="bengaluru" and i.Destination="chennai";

#4
select 
u.fname,
u.lname
from users as u inner join (select t.user_id from ticket as t 
inner join payment_info as p where p.pnr=t.pnr and p.price>500) as a where  a.user_id=u.user_id; 


#5
select u.fname,
u.lname,
u.dob,
t.pnr
from users as u left outer join ticket as t on t.user_id=u.user_id
order by u.Fname;



#6
select u.fname, u.lname
from users as u left outer join ticket as t on t.user_id=u.user_id
where t.user_id is null;



#7
select t.pnr,t.travel_date,t.train_number,u.fname,u.lname
from ticket as t right outer join users as u 
on t.User_Id=u.User_Id 
order by u.Fname;


#8
select  u.user_id ,t.train_number
from ticket as t right outer join users as u 
on t.User_Id=u.User_Id 
where t.pnr is not null;



#9
select t.train_no,t.train_name 
from train as t  
where t.Train_No not in
(select t.train_no from ticket as t 
where t.Departure_time!="20:30:00" and t.train_no not in
(select t.Train_no from route_info as t 
where t.Distance>=100 and t.to_station_name="mangaluru" ) );










#10
select t.user_id from ticket as t 
where t.pnr in (select t.pnr from payment_info as t 
where t.price > (select avg(t.price) as a 
from payment_info as t));




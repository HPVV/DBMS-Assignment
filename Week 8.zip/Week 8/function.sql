DELIMITER $$
CREATE FUNCTION MaxTicketNo(User_ID varchar(255),count int)
returns varchar(100)
deterministic
BEGIN
    declare ret_ans varchar(100);
    
    if count>2 then
		set ret_ans='cannot purchase tickets';
	else 
		set ret_ans='can purchase tickets';
    
    end if;
    return ret_ans;
END; $$
DELIMITER ;

select count(user_id),user_id, MaxTicketNo(User_ID,count(User_ID))
from ticket group by user_id;






delimiter $$
create procedure count_age(in dateofbirth date,out age int)
BEGIN

	SET age = DATE_FORMAT(FROM_DAYS(DATEDIFF(now(), dateofbirth)), '%Y') + 0;
	
end; $$
delimiter ;

set @age = 0;

call railwayreservationsystem.count_age('1983-09-27', @age);
select @age